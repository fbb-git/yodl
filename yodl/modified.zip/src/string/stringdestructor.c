#include "string.ih"

void string_destructor(register void *sp)
{
    string_free((String *)sp);
    free(sp);
}
